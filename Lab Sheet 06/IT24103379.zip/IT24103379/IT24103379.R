setwd("C:\\Users\\uvind\\Downloads\\IT24103379")

##Question 01
##i)Distribution of n = 50 and p = 0.85
pbinom(47,50,0.85,lower.tail = FALSE)
##we use false if the value is greater
##Question 02
##i)Number of average calls receives per hour
##ii)Poisson Distribution
dpois(15,12)